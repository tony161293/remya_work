<?php
$name = $_POST['name'];
$status = $_POST['status'];
$occupation = $_POST['occupation'];
$district = $_POST['district'];
$qualification = $_POST['qualification'];
$maxval = $_POST['maxval'];
$gender = $_POST['gender'];
$age = $_POST['age'];
$address = $_POST['address'];
$comaddress = $_POST['comaddress'];
$cooperation = $_POST['cooperation'];
$recommend = $_POST['recommend'];
$relation = $_POST['relation'];
				$to       = "tony161293@gmail.com";
				$subject  = 'Beneficiary Submission details';
				$headers  = 'From: Silent Spring \r\n' .
				"www.silentspringkerala.org \r\n" .
				'This is an automated email, please dont'."\r\n" .
				'MIME-Version: 1.0' . "\r\n" .
				'Content-type: text/html; charset=iso-8859-1' . "\r\n" .
				'X-Mailer: PHP/' . phpversion();
				$message  = '
				<html>
				<body>
				<table>
				<th>Specification</th>
				<th>Value</th>
				<td>
				<tr>Name</tr>
				<tr>'.$name.'</tr>
				</td>
				<td>
				<tr>Status</tr>
				<tr>'.$status.'</tr>
				</td>
				<td>
				<tr>Occupation</tr>
				<tr>'.$occupation.'</tr>
				</td>
				<td>
				<tr>District</tr>
				<tr>'.$district.'</tr>
				</td>
				<td>
				<tr>Qualification</tr>
				<tr>'.$qualification.'</tr>
				</td>
				<td>
				<tr>Address</tr>
				<tr>'.$address.'</tr>
				</td>
				<td>
				<tr>Communication address</tr>
				<tr>'.$comaddress.'</tr>
				</td>
				<td>
				<tr>Recommended by</tr>
				<tr>'.$movingdate.'</tr>
				</td>
				<td>
				<tr>Cooperation</tr>
				<tr>'.$cooperation.'</tr>
				</td>
				</table>
				</body>
				</html>
				';

mail($to, $subject, $message, $headers);

?>
